# Comparative Effectiveness of Three Drugs in Reducing Systolic Blood Pressure
# MICHAEL OKANTA
# 2024-09-13

# Load necessary packages
library(tidyverse)
library(gridExtra)
library(knitr)
library(emmeans)

# Read in data
bpdata <- read.csv("C:\\Users\\micha\\Documents\\STA 660\\Project 1 - Blood Pressure\\bloodpressurestudy.csv", 
                   header=T)
#names(bpdata)

### Data processing and calculation of different endpoints

bpdata <- bpdata %>%
  mutate(subject = factor(subject),
         BPchange = after-before) %>%  # % drop rel to 120 (interp?)
  rename(ID = subject,
         Drug = drug, 
         SysBP.pre = before, 
         SysBP.post = after)

### Mean responses by drug
means <- bpdata %>%
  group_by(Drug) %>%
  summarize(across(where(is.numeric), mean, .names = "mean_{col}"))

### SDs of responses by drug
sds <- bpdata %>%
  group_by(Drug) %>%
  summarize(across(where(is.numeric), sd, .names = "sd_{col}")) 

# Join the two tables
combined <- inner_join(means, sds, by = "Drug")

# Rename columns for readability
combined <- combined %>%
  rename(
    `Mean Pre-treatment SBP` = mean_SysBP.pre,
    `Mean Post-treatment SBP` = mean_SysBP.post,
    `Mean BP Change` = mean_BPchange,
    `SD Pre-treatment SBP` = sd_SysBP.pre,
    `SD Post-treatment SBP` = sd_SysBP.post,
    `SD BP Change` = sd_BPchange
  ) %>%
  kable()

combined

# Visualization of relationships
ggplot(bpdata, aes(x=SysBP.pre, y=SysBP.post, shape=Drug, colour=Drug, fill=Drug)) +
  geom_smooth(method="lm") +
  geom_point() +
  labs(x = "Pre-study Systolic BP (mmHg)",
       y = "Post-study Systolic BP (mmHg)")

# Fit the One-way ANCOVA model: Post-study ~ Pre-study BP (covariate) + Drug (factor)
ancova_change_model <- lm(SysBP.post ~ SysBP.pre + Drug, data = bpdata)

# Show the summary of the model
summary(ancova_change_model)

# Normality of Residuals: Q-Q Plot
qqnorm(residuals(ancova_change_model))  # Q-Q plot to check for normality
qqline(residuals(ancova_change_model))  # Add a reference line

# Homoscedasticity: Residuals vs Fitted Plot
plot(fitted(ancova_change_model), residuals(ancova_change_model), 
     xlab = "Fitted Values", ylab = "Residuals", 
     main = "Residuals vs Fitted")
abline(h = 0, col = "red")

# Residuals Histogram: Another way to check the distribution of residuals
hist(residuals(ancova_change_model), 
     main = "Histogram of Residuals", 
     xlab = "Residuals", 
     col = "lightblue")

emmeans(ancova_change_model, specs = pairwise ~ Drug)

# Predicted values
predict(ancova_change_model)  # original predictions from ANCOVA

## Cursory check for consistent distributions between trt groups at pre stage:
## Permutation F-test on rank positions

## Using ranks reduces the problem to assessing relative position of observations
## to each other with respect to group membership

## Under a null hypothesis of "pre BPs are randomly mixed across trt groups",
## we can use an F statistic to see if "mean positions" are consistent w/ random mixture

## Using a permutation test approach divorces us from needing to be concerned
## w/ normality and equal variance assumptions.  We are only using the construction
## of an F-statistic to compare 'between' to 'within' group rankings

# create joint rankings
rankdata <- bpdata %>%
  mutate(BP.pre.rank= rank(SysBP.pre)) %>%
  select(Drug, SysBP.pre, BP.pre.rank)
rankdata  # peek

# calculate/extract F-statistic from observed data, using ranks as the response 
raw.results <- lm(BP.pre.rank ~ Drug, data=rankdata)
Fobs <- summary(raw.results)$f[1]
Fobs

# perform permutations: 1) randomly reassign persons to drugs
#                       2) recalculate F-stat
#                       3) repeat steps 1 and 2 10000 times
#                       4) check if Fobs is consistent w/ randomized results

reps <- numeric(9999)
for (i in 1:9999) {
  perm.data <- data.frame(Drug = rankdata$Drug,
                          permuted.rank = sample(rankdata$BP.pre.rank))
  shuffled.results <- lm(permuted.rank ~ Drug, data=perm.data) 
  reps[i] <- summary(shuffled.results)$f[1]
}

# Visualization of the null distribution (under random assignment)
ggplot(data.frame(reps), aes(x=reps)) + 
  geom_histogram() +
  geom_vline(xintercept = Fobs, color="red", linetype="longdash") +
  labs(title="Null distribution of permuted F-statitsic",
       x="Simulated F values under Ho")

# p-value
pvalue <- mean(c(Fobs, reps) >= Fobs)
cat("The observed TS is F =", Fobs,"; p-value =", pvalue, "\n")


